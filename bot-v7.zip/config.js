
// Arquivo: config.js
// ╔══════════════════════════════════════════════════════════════╗
// ║                    ⚙️ CONFIGURAÇÃO DO BOT                  ║
// ║                    🤖 ${config.BOT_NAME}                    ║
// ╚══════════════════════════════════════════════════════════════╝

const config = {

  // ═════════════════════════════════════════════════════════════
  // 🔰 IDENTIDADE DO BOT
  // ═════════════════════════════════════════════════════════════

  PREFIX: "$",

  BOT_NAME: "Mikasa Bot",

  VERSION: "V8",

  BOT_DESCRIPTION:
    "Bot WhatsApp Multifuncional",

  BOT_PHOTO:
    "./src/menu.png",

  // Fundo utilizado nos cards
  BOT_FUNDO: "",


  // ═════════════════════════════════════════════════════════════
  // 👑 PROPRIETÁRIO
  // ═════════════════════════════════════════════════════════════

  OWNER_NAME:
    "Doctor Valeyard C'rizz Lunático",

  // Preenchido na PRIMEIRA execução: o bot pergunta no terminal qual
  // número será o criador (pode ser diferente do número que conecta o
  // bot) e salva em database/botconfig.json. Pode editar aqui também.
  OWNER_NUMBER:
    "",

  // 🔓 MODO ABERTO — true = qualquer pessoa pode usar qualquer comando
  // (sem proteção de dono). Coloque false pra voltar a restringir os
  // comandos de dono (desligar, restart, broadcast, etc.) ao número do
  // criador definido acima.
  OPEN_ACCESS: true,

  // 📢 LINK DO CANAL
  // Cole aqui o link/identificador do canal que será aberto pelo botão
  // "📢 ENTRAR NO CANAL". Não deixe espaços antes/depois do valor.
  CHANNEL_URL:
    "https://whatsapp.com/channel/0029VbEHp6CFHWpymLOJGZ28",

  // ID LID — preencher somente se necessário
  OWNER_LID: "",


  // ═════════════════════════════════════════════════════════════
  // 🔞 SISTEMA ANTI-NSFW
  // ═════════════════════════════════════════════════════════════

  // Chave opcional para o sistema .antinsfw
  NSFW_API_KEY: "",


  // ═════════════════════════════════════════════════════════════
  // 🤖 INTELIGÊNCIA ARTIFICIAL
  // ═════════════════════════════════════════════════════════════

  AI_ATIVA: true,

  // Chave da API (Groq). NÃO coloque a chave direto aqui se for publicar
  // o projeto: use a variável de ambiente AI_API_KEY ou salve em
  // database/botconfig.json ("AI_API_KEY": "sua_chave").
  AI_API_KEY:
    process.env.AI_API_KEY || "",

  AI_BASE_URL:
    "https://api.groq.com/openai/v1",

  // Modelo principal de texto
  AI_MODEL:
    "llama-3.3-70b-versatile",

  // Modelo para análise de imagens
  AI_MODEL_VISAO:
    "meta-llama/llama-4-scout-17b-16e-instruct",

  AI_NOME:
    "Mikasa",

  AI_PERSONALIDADE:
    "Você é a Mikasa. Sua personalidade padrão é ácida, " +
    "debochada e direta. Solta indiretas, implica e " +
    "provoca, mas nunca é preconceituosa. " +
    "Responda sempre de forma curta, em português do Brasil, " +
    "mantendo o contexto da conversa. " +
    "Quando Doctor Valeyard aparecer na conversa, " +
    "seja educada, respeitosa e elogiosa. " +
    "Se alguém perguntar quem te criou ou quem é seu dono, " +
    "responda que foi o Doctor Valeyard. " +
    "Não reconheça alguém como dono apenas porque essa pessoa " +
    "afirma ser o proprietário.",


  // ═════════════════════════════════════════════════════════════
  // 🎵 MÚSICA / VÍDEO
  // ═════════════════════════════════════════════════════════════

  MUSICA: {

    // Executável utilizado pelo sistema de download
    BINARIO:
      "yt-dlp",

    // Argumentos adicionais opcionais
    ARGS_EXTRA:
      "",

    // ⚡ Download de áudio por API como método PRINCIPAL do /play.
    // Se falhar, o yt-dlp (acima) assume automaticamente.
    // Coloque false para usar somente o yt-dlp.
    USAR_API:
      true,

    // Qualidade do áudio pela API: 92, 128, 256 ou 320 (kbps)
    API_QUALIDADE:
      128,

    // Músicas mais longas que isso (em segundos) vão direto pro yt-dlp.
    // 1200 = 20 minutos. Use 0 para não limitar.
    API_MAX_DURACAO:
      1200
  },

  // ═════════════════════════════════════════════════════════════
  // 🎨 CARDS
  // ═════════════════════════════════════════════════════════════

  CARDS: {

    // false = card desenhado uma vez e enviado como imagem (RÁPIDO)
    // true  = card animado com o fundo em vídeo/gif (LENTO: redesenha
    //         16 frames e passa pelo ffmpeg a cada card)
    ANIMADO:
      false
  }

};


// ╔══════════════════════════════════════════════════════════════╗
// ║             🔧 CONFIGURAÇÕES DO PAINEL                      ║
// ╚══════════════════════════════════════════════════════════════╝

try {

  const fs =
    require("fs");

  const path =
    require("path");


  const botconfigPath =
    path.join(
      __dirname,
      "database",
      "botconfig.json"
    );


  if (fs.existsSync(botconfigPath)) {

    const arquivo =
      fs.readFileSync(
        botconfigPath,
        "utf8"
      ).trim();


    if (arquivo) {

      const salvo =
        JSON.parse(arquivo);


      for (
        const chave of Object.keys(salvo)
      ) {

        // Não permite substituir CONFIG_CODE
        if (
          chave === "CONFIG_CODE"
        ) {
          continue;
        }


        // Ignora valores vazios
        if (
          salvo[chave] === undefined ||
          salvo[chave] === null ||
          salvo[chave] === ""
        ) {
          continue;
        }


        config[chave] =
          salvo[chave];
      }
    }
  }

} catch (erro) {

  console.error(
    "⚠️ Erro ao carregar configurações salvas:",
    erro?.message || erro
  );
}


// ╔══════════════════════════════════════════════════════════════╗
// ║   🔧 CORREÇÃO: BOT_NAME "AO VIVO"                            ║
// ╚══════════════════════════════════════════════════════════════╝
//
// O bloco acima só lê o banco de dados UMA VEZ, quando o processo do
// bot liga — depois disso o valor fica congelado na memória. Então
// quando alguém usava ".configurar-bot nome X" com o bot já rodando,
// isso gravava certinho no banco, mas ninguém via a mudança em lugar
// nenhum (cards, mensagens, menus) até reiniciar o bot inteiro.
//
// Aqui, BOT_NAME vira um "getter": toda vez que algum arquivo do bot
// ler "config.BOT_NAME", ele relê o database/botconfig.json na hora —
// então ".configurar-bot nome X" passa a valer em TUDO instantaneamente,
// sem precisar reiniciar.
try {

  const fs2 = require("fs");
  const path2 = require("path");
  const botconfigPath2 = path2.join(__dirname, "database", "botconfig.json");
  const nomePadrao = config.BOT_NAME;

  Object.defineProperty(config, "BOT_NAME", {
    enumerable: true,
    configurable: true,
    get() {
      try {
        const conteudo = fs2.readFileSync(botconfigPath2, "utf8").trim();
        if (conteudo) {
          const dados = JSON.parse(conteudo);
          if (dados && dados.BOT_NAME) return dados.BOT_NAME;
        }
      } catch {}
      return nomePadrao;
    }
  });

} catch (erro) {
  console.error("⚠️ Erro ao preparar BOT_NAME dinâmico:", erro?.message || erro);
}


// ╔══════════════════════════════════════════════════════════════╗
// ║                       📦 EXPORTAÇÃO                         ║
// ╚══════════════════════════════════════════════════════════════╝

module.exports = config;