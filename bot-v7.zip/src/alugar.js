const config = require("../config");
const { getDB, saveDB } = require("./grupo-db");
const { ehDono } = require("./utils-validacao");
const { isAdmin } = require("./grupo");

function soNumeros(v) {
    return String(v || "").replace(/\D/g, "");
}

async function alugar(sock, msg, args) {
    const from = msg.key.remoteJid;
    const isGroup = from.endsWith("@g.us");
    const remetente = msg.key.participant || msg.key.remoteJid;
    const numeroRemetente = soNumeros(remetente);
    const donoBot = ehDono([remetente, msg.key.participantAlt, from], config.OWNER_NUMBER);

    // ──────────────────────────────────────────────────────────────
    // Ex: .alugar 1  → ativa o bot nesse grupo
    //     .alugar 0  → desativa o bot nesse grupo
    // Sem VIP, sem plano e sem limite de grupos.
    // ──────────────────────────────────────────────────────────────
    const userAdmin = isGroup && !donoBot ? await isAdmin(sock, from, remetente).catch(() => false) : false;

    if (isGroup) {
        const argumento = String(args?.[0] || "").toLowerCase();
        const ligarPalavras = ["1", "on", "ativar", "ativado"];
        const desligarPalavras = ["0", "off", "desativar", "desativado"];

        if (ligarPalavras.includes(argumento)) {
            const db = getDB();
            const jaEraDela = db[from]?.alugado === true && soNumeros(db[from]?.alugadoPor) === numeroRemetente;

            // 🔐 Só administrador do grupo (ou o dono, quando o modo aberto
            // estiver desligado) pode ativar. Sem limite de grupos.
            if (!donoBot && !(userAdmin || jaEraDela)) {
                return sock.sendMessage(from, {
                    text: `🚫 Só um *administrador do grupo* pode ativar o bot aqui.`
                }, { quoted: msg });
            }

            if (!db[from]) db[from] = {};
            db[from].alugado = true;
            db[from].alugadoPor = donoBot ? "" : numeroRemetente;
            db[from].alugadoEm = Date.now();
            saveDB(db);

            return sock.sendMessage(from, {
                text: `✅ *GRUPO ALUGADO* ✅\n\n💰 O bot agora está liberado pra funcionar normalmente neste grupo.\n\n🤍 ${config.BOT_NAME}`
            }, { quoted: msg });
        }

        if (desligarPalavras.includes(argumento)) {
            const db = getDB();

            // 🔐 Só o dono, quem ativou ou um administrador do grupo pode desativar.
            if (!donoBot && !userAdmin && soNumeros(db[from]?.alugadoPor) !== numeroRemetente) {
                return sock.sendMessage(from, {
                    text: `🚫 Só um *administrador do grupo* pode desativar o bot aqui.`
                }, { quoted: msg });
            }

            if (!db[from]) db[from] = {};
            db[from].alugado = false;
            db[from].alugadoPor = "";
            saveDB(db);

            return sock.sendMessage(from, {
                text: `❌ *ALUGUEL ENCERRADO* ❌\n\n💰 O bot foi desativado neste grupo — nenhum comando vai funcionar aqui até ser alugado de novo (nem para administradores).\n\n🤍 ${config.BOT_NAME}`
            }, { quoted: msg });
        }

        // usou ".alugar" sem argumento válido dentro de um grupo — mostra status + instrução
        const db = getDB();
        const estadoAtual = db[from]?.alugado === true;
        const mensagemStatus = `
╭─── ❀ ───
💰 SISTEMA DE ALUGUEL
╰─── ❀ ───

📊 Este grupo está: ${estadoAtual ? "🟢 ALUGADO" : "🔴 NÃO ALUGADO"}

❀ Use:
${config.PREFIX}alugar 1  → ativa o bot aqui
${config.PREFIX}alugar 0  → desativa o bot aqui

❀────────────────────❀
🤍 ${config.BOT_NAME}
❀────────────────────❀`;
        return sock.sendMessage(from, { text: mensagemStatus }, { quoted: msg });
    }

    // ──────────────────────────────────────────────────────────────
    // Qualquer outra pessoa (ou uso fora de grupo): mensagem de
    // divulgação de sempre, sem mexer em nada.
    // ──────────────────────────────────────────────────────────────
    const resp = `ℹ️ Use *${config.PREFIX}alugar 1* (ativar) ou *${config.PREFIX}alugar 0* (desativar) dentro de um grupo.`;
    await sock.sendMessage(from, { text: resp }, { quoted: msg });
}

module.exports = { alugar };
