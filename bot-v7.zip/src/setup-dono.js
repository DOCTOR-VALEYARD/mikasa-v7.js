// ==================================================
// 👑 SETUP INICIAL DO CRIADOR
// 📁 Arquivo: src/setup-dono.js
//
// Na PRIMEIRA vez que o bot é iniciado (ex.: no Termux), pergunta no
// terminal qual número vai ser o CRIADOR do bot — que pode ser diferente
// do número que vai conectar o bot ao WhatsApp. O valor fica salvo em
// database/botconfig.json e essa pergunta não aparece mais nas próximas
// execuções.
//
// Pra trocar depois: use o comando "configurar-bot numero <número>" no
// WhatsApp, ou apague OWNER_CONFIGURADO do database/botconfig.json pra
// o bot perguntar de novo.
// ==================================================

const fs = require("fs");
const path = require("path");
const readline = require("readline");

const botconfigPath = path.join(__dirname, "..", "database", "botconfig.json");

function lerConfigSalva() {
    try {
        if (!fs.existsSync(botconfigPath)) return {};
        const texto = fs.readFileSync(botconfigPath, "utf8").trim();
        return texto ? JSON.parse(texto) : {};
    } catch {
        return {};
    }
}

function salvarConfig(dados) {
    fs.mkdirSync(path.dirname(botconfigPath), { recursive: true });
    fs.writeFileSync(botconfigPath, JSON.stringify(dados, null, 2) + "\n", "utf8");
}

function perguntar(rl, texto) {
    return new Promise((resolve) => rl.question(texto, (resposta) => resolve(String(resposta || "").trim())));
}

function soNumeros(valor) {
    return String(valor || "").replace(/\D/g, "");
}

/**
 * Garante que existe um número de criador configurado. Se não existir,
 * pergunta no terminal. Atualiza também o objeto `config` em memória,
 * então o resto do bot já usa o número novo sem precisar reiniciar.
 *
 * @param {object} config - o módulo ../config (será atualizado)
 */
async function garantirDonoConfigurado(config) {
    const salva = lerConfigSalva();

    // Já configurado antes → segue direto.
    if (salva.OWNER_CONFIGURADO === true && soNumeros(salva.OWNER_NUMBER)) {
        config.OWNER_NUMBER = soNumeros(salva.OWNER_NUMBER);
        return;
    }

    // Se alguém já deixou um número válido no config.js / botconfig.json
    // na mão, respeita e não pergunta.
    const numeroJaDefinido = soNumeros(salva.OWNER_NUMBER || config.OWNER_NUMBER);
    if (numeroJaDefinido.length >= 10) {
        salva.OWNER_NUMBER = numeroJaDefinido;
        salva.OWNER_CONFIGURADO = true;
        salvarConfig(salva);
        config.OWNER_NUMBER = numeroJaDefinido;
        return;
    }

    // Sem terminal interativo (ex.: rodando em segundo plano) não dá pra
    // perguntar — avisa e segue.
    if (!process.stdin.isTTY) {
        console.log("⚠️ Número do criador ainda não configurado e não há terminal interativo para perguntar.");
        console.log("   Rode o bot direto no terminal uma vez, ou preencha OWNER_NUMBER em database/botconfig.json.");
        return;
    }

    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

    console.log(`
╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮
   👑 CONFIGURAÇÃO DO CRIADOR DO BOT 👑
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

Qual número vai ficar como CRIADOR do bot?

💡 Esse NÃO precisa ser o número que vai conectar
   o bot — é o número que aparece como criador nos
   menus e no botão "Falar com o criador".

📝 Digite com código do país + DDD + número.
   Exemplo: 5511999998888
──────────────────────────────────────────`);

    let numero = "";
    while (!numero) {
        const resposta = soNumeros(await perguntar(rl, "➜ "));

        if (resposta.length < 10 || resposta.length > 15) {
            console.log("\n❌ Número inválido! Use código do país + DDD + número (de 10 a 15 dígitos).\n");
            continue;
        }

        const confirmacao = (await perguntar(rl, `\n✅ O criador será +${resposta}. Está certo? [S/n] `)).toLowerCase();
        if (confirmacao === "" || confirmacao.startsWith("s") || confirmacao.startsWith("y")) {
            numero = resposta;
        } else {
            console.log("\n🔁 Ok, digite o número de novo:\n");
        }
    }

    console.log(`
💡 Se quiser, digite também o NOME do criador que vai aparecer
   no bot. Se não quiser mudar, é só apertar ENTER.`);
    const nome = await perguntar(rl, "➜ ");

    rl.close();

    salva.OWNER_NUMBER = numero;
    salva.OWNER_CONFIGURADO = true;
    config.OWNER_NUMBER = numero;

    if (nome) {
        salva.OWNER_NAME = nome;
        config.OWNER_NAME = nome;
    }

    salvarConfig(salva);

    console.log(`
╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮
   ✅ TUDO CERTO!
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

👑 Criador: +${numero}${nome ? `\n📛 Nome: ${nome}` : ""}

Agora vamos conectar o bot ao WhatsApp...
──────────────────────────────────────────
`);
}

module.exports = { garantirDonoConfigurado };
